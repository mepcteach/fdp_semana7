/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arregloejemplo;

/**
 *
 * @author mpuebla
 */
public class ArregloEjemplo {
    public static void main(String[] args) {
        // Crear un array de enteros con tamaño 5
        int[] numeros = new int[5];

        // Inicializar el array
        numeros[0] = 10;
        numeros[1] = 20;
        numeros[2] = 30;
        numeros[3] = 40;
        numeros[4] = 50;

        // Acceder a un elemento específico
        System.out.println("Elemento en el índice 2: " + numeros[2]);

        // Recorrer el array con un bucle for
        System.out.println("Recorriendo el array:");
        for (int i = 0; i < numeros.length; i++) {
            System.out.println("Elemento en el índice " + i + ": " + numeros[i]);
        }

        // Recorrer el array con un bucle for-each
        System.out.println("Recorriendo el array con for-each:");
        for (int numero : numeros) {
            System.out.println(numero);
        }

        // Crear y mostrar un array multidimensional (matriz)
        int[][] matriz = {
            {1, 2, 3},   // 1: (0,0) -  2: (0,1)
            {4, 5, 6},
            {7, 8, 9}     // 8: (2,1)
        };
        
         

        System.out.println("Elementos de la matriz:");
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println();
        }
        
        
       System.out.println("Accedemos directo a un elemento de la matriz:");
        System.out.print(matriz[2][1]);
    }
}
