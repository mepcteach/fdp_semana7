/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.iteracionlistayarreglo;

/**
 *
 * @author mpuebla
 */
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class IteracionListaYArreglo {
    public static void main(String[] args) {
        // Crear un ArrayList de enteros
        List<Integer> lista = new ArrayList<>();
        lista.add(1);
        lista.add(2);
        lista.add(3);
        lista.add(4);
        lista.add(5);
        
        // Iteración usando un bucle for clásico
        System.out.println("Iterando ArrayList con bucle for clásico:");
        for (int i = 0; i < lista.size(); i++) {
            System.out.println("Elemento en índice " + i + ": " + lista.get(i));
        }
        
        // Iteración usando for-each
        System.out.println("\nIterando ArrayList con bucle for-each:");
        for (int numero : lista) {
            System.out.println(numero);
        }
        
        // Iteración usando Iterator
        System.out.println("\nIterando ArrayList con Iterator:");
        Iterator<Integer> iterador = lista.iterator();
        while (iterador.hasNext()) {
            System.out.println(iterador.next());
        }

        // Crear un array
        int[] arreglo = {10, 20, 30, 40, 50};

        // Iteración usando un bucle for clásico
        System.out.println("\nIterando Array con bucle for clásico:");
        for (int i = 0; i < arreglo.length; i++) {
            System.out.println("Elemento en índice " + i + ": " + arreglo[i]);
        }

        // Iteración usando for-each
        System.out.println("\nIterando Array con bucle for-each:");
        for (int numero : arreglo) {
            System.out.println(numero);
        }
    }
}
