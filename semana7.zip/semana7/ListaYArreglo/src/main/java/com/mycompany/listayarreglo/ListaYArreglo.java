/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.listayarreglo;

/**
 *
 * @author mpuebla
 */
import java.util.ArrayList;
import java.util.List;

public class ListaYArreglo {
    public static void main(String[] args) {
        // Crear un ArrayList de enteros
        List<Integer> lista = new ArrayList<>();
        
        // Agregar elementos al ArrayList
        lista.add(10);
        lista.add(20);
        lista.add(30);
        lista.add(40);
        
        System.out.println("Elementos en la lista:");
        for (int numero : lista) {
            System.out.println(numero);
        }
        
        // Convertir ArrayList a array
        Integer[] arreglo = lista.toArray(new Integer[0]);
        
        System.out.println("\nElementos en el array:");
        for (int i = 0; i < arreglo.length; i++) {
            System.out.println("Elemento en el índice " + i + ": " + arreglo[i]);
        }

        // Crear un array y pasarlo a una lista
        String[] nombres = {"Miguel", "Ana", "Luis"};
        List<String> listaNombres = new ArrayList<>();
        
        // Llenar la lista con los elementos del array
        for (String nombre : nombres) {
            listaNombres.add(nombre);
        }
        
        System.out.println("\nElementos en la lista de nombres:");
        for (String nombre : listaNombres) {
            System.out.println(nombre);
        }
    }
}
