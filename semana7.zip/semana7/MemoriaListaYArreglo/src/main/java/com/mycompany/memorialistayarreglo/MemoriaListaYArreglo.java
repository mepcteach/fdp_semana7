/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.memorialistayarreglo;

/**
 *
 * @author mpuebla
 */
import java.util.ArrayList;
import java.util.List;

public class MemoriaListaYArreglo {
    public static void main(String[] args) {
         
        List<Integer> lista = new ArrayList<>();
        
        lista.add(4);
        lista.add(30);
         
        
        // Agregar elementos a la lista
        for (int i = 0; i < 15; i++) {
            lista.add(i);
        }
        System.out.println("Elementos en la lista después de agregar 15 elementos: " + lista.size());
        
        // Uso de memoria interna (redimensionamiento)
        System.out.println("El ArrayList se redimensionó automáticamente a medida que se agregaron elementos.");

        // Crear un array de tamaño fijo
        int[] arreglo = new int[5];
        System.out.println("\nTamaño del array: " + arreglo.length);
        
        // Llenar el array
        for (int i = 0; i < arreglo.length; i++) {
            arreglo[i] = i * 2;
        }
        
        System.out.println("Array lleno:");
        for (int numero : arreglo) {
            System.out.println(numero);
        }

        // Intentar redimensionar el array (no se puede)
        System.out.println("El array tiene un tamaño fijo y no se puede redimensionar.");
    }
}
